package com.example.uasmobile;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {
    private Context context;
    private ArrayList<Menu> menus;


    public MenuAdapter(Context mcontext, ArrayList<Menu> menumakan) {
        context = mcontext;
        menus = menumakan;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.itemmenu,parent, false);
        return new MenuViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        Menu menubaru = menus.get(position);
        String nama= menubaru.getNama();
        String deskripsi= menubaru.getDeskripsi();
        String harga= menubaru.getHarga();
        String gambarbaru= menubaru.getGambar();


        holder.tvnama.setText(nama);
        holder.tvdeskripsi.setText(deskripsi);
        holder.tvharga.setText(harga);

Glide .with(context)
        .load(gambarbaru)
        .centerCrop()
        .into(holder.imdata);


    }

    @Override
    public int getItemCount() {
        return menus.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder {
        public ImageView imdata;
        public TextView tvnama;
        public TextView tvdeskripsi;
        public TextView tvharga;
        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            tvnama = itemView.findViewById(R.id.tvnama);
            tvdeskripsi = itemView.findViewById(R.id.tvdeskripsi);
            tvharga = itemView.findViewById(R.id.tvharga);
            imdata = itemView.findViewById(R.id.gambar1);

        }
    }
}