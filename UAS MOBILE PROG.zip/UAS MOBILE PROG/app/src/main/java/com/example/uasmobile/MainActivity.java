package com.example.uasmobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    CardView Menukami, Contact, Location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Menukami = findViewById(R.id.Menukami);
        Menukami.setOnClickListener(this);

        Contact = findViewById(R.id.Contact);
        Contact.setOnClickListener(this);

        Location = findViewById(R.id.Location);
        Location.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.Menukami) {
            Intent pindah = new Intent(MainActivity.this, MenuActivity.class);
            startActivity(pindah);
        } else if (v.getId() == R.id.Contact) {
            String tlpn = "085857222595";
            Intent dialinten = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + tlpn));
            startActivity(dialinten);
        }
        else if (v.getId()== R.id.Location){
            Intent pindah = new Intent( MainActivity.this, MapsActivity.class);
            startActivity(pindah);
        }

    }
}