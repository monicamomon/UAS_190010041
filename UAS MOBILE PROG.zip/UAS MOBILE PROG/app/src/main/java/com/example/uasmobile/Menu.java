package com.example.uasmobile;

public class Menu {
    private String nama;
    private String deskripsi;
    private String gambar;
    private String harga;

    public Menu(String datanama, String datadeskripsi, String datagambar, String dataharga){
    nama=datanama;
    deskripsi=datadeskripsi;
    gambar=datagambar;
    harga=dataharga;
}


    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }
}
